<h1>Contacts</h1>

<?php
if ($contacts) {
    foreach($contacts as $contact) {
        echo $contact.'<br>';
    }
}
?>
