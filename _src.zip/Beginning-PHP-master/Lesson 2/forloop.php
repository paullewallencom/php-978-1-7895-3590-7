<?php

    $food = array("turkey", "milk", "apples");

    for($i = 0; $i < count($food); $i++){
        echo $food[$i] . "\n";
    }

?>