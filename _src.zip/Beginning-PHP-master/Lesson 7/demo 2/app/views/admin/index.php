<?php
include(APPDIR.'views/layouts/header.php');
include(APPDIR.'views/layouts/nav.php');
include(APPDIR.'views/layouts/errors.php');
?>

<h1>Dashboard</h1>
<p>This is the application dashboard.</p>

<?php include(APPDIR.'views/layouts/footer.php');?>
