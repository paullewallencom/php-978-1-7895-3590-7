<?php
	function addNumbers($a, $b)
	{
		return $a + $b;
	}
	echo addNumbers(5,6);
?>